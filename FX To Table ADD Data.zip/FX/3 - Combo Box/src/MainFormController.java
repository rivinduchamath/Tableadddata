import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.ObservableList;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;

import java.util.ArrayList;

public class MainFormController {

    public ComboBox<String> cmbNames;
    public Label lblOutput;

    public void initialize(){
        ObservableList<String> items = cmbNames.getItems();

        items.add("First");
        items.add("Second");
        items.add("Third");
        items.add("Fourth");
        items.add("Fifth");

        cmbNames.getSelectionModel().select(0);

        cmbNames.getSelectionModel().selectedItemProperty().addListener(new ChangeListener<String>() {
            @Override
            public void changed(ObservableValue<? extends String> observable, String oldValue, String newValue) {
                //String selectedItem = cmbNames.getSelectionModel().getSelectedItem();
                lblOutput.setText(newValue);
            }
        });
    }

}
