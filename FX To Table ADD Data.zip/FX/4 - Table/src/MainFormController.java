import javafx.collections.ObservableList;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;

import java.net.URL;
import java.util.ResourceBundle;

public class MainFormController{

    public TableView<CustomerTM> tblCustomers;

    public void initialize(){

        // Let's map columns
        tblCustomers.getColumns().get(0).setCellValueFactory(new PropertyValueFactory<>("id"));
        tblCustomers.getColumns().get(1).setCellValueFactory(new PropertyValueFactory<>("name"));
        tblCustomers.getColumns().get(2).setCellValueFactory(new PropertyValueFactory<>("address"));
        tblCustomers.getColumns().get(3).setCellValueFactory(new PropertyValueFactory<>("delete"));

        ObservableList<CustomerTM> items = tblCustomers.getItems();
        items.add(new CustomerTM("C001","Kasun","Galle",new Button("Delete")));
        items.add(new CustomerTM("C002","Nuwan","Galle",new Button("Delete")));
        items.add(new CustomerTM("C003","Nimal","Galle",new Button("Delete")));
        items.add(new CustomerTM("C004","Ranil","Galle",new Button("Delete")));

    }

}
