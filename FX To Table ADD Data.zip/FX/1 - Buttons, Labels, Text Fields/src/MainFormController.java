import javafx.event.ActionEvent;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;

public class MainFormController {
    public TextField txtSomething;
    public Label lblOutput;

    public void btnSubmit_OnAction(ActionEvent actionEvent) {
        lblOutput.setText(txtSomething.getText());
    }

    public void btnClear_OnAction(ActionEvent actionEvent) {
        txtSomething.clear();
        lblOutput.setText("");
        txtSomething.requestFocus();
    }

}
