import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.scene.control.*;
import javafx.scene.input.MouseEvent;

public class MainFormController {

    public ListView<String> lstNames;
    public TextField txtSomething;
    public Label lblOutput;

    public void initialize(){

        ObservableList<String> items = lstNames.getItems();

        items.add("First");
        items.add("Second");
        items.add("Third");
        lstNames.getItems().add("Fourth");

        lstNames.getSelectionModel().selectedItemProperty().addListener(new ChangeListener<String>() {
            @Override
            public void changed(ObservableValue<? extends String> observable, String oldValue, String newValue) {
                String selectedItem = lstNames.getSelectionModel().getSelectedItem();
                lblOutput.setText(selectedItem);
            }
        });
    }

    public void btnAdd_OnAction(ActionEvent actionEvent) {
        ObservableList items = lstNames.getItems();
        items.add(txtSomething.getText());
        txtSomething.requestFocus();
        txtSomething.selectAll();
    }

    public void btnClearAll_OnAction(ActionEvent actionEvent) {
        ObservableList items = lstNames.getItems();
        items.clear();
    }

    public void btnRemoveSelected_OnAction(ActionEvent actionEvent) {
        int selectedIndex = lstNames.getSelectionModel().getSelectedIndex();
        lstNames.getItems().remove(selectedIndex);
    }

    public void lstNames_OnClick(MouseEvent mouseEvent) {

    }

    public void txtSomething_OnAction(ActionEvent actionEvent) {
        btnAdd_OnAction(actionEvent);
    }
}
