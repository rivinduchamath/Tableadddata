import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.scene.control.ComboBox;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;

import java.util.ArrayList;

public class CustomerFormController {
    public TextField txtStudentId;
    public TextField txtStudentName;
    public ComboBox<String> cmbCourse;
    public ListView<String> lstCourses;
    public ComboBox<String> cmbStudentID;
    public TextField txtName;

    private ArrayList<Student> studentsDB = new ArrayList<>();

    public void initialize(){
        ObservableList courses = cmbCourse.getItems();
        courses.clear();
        courses.add("CMJD");
        courses.add("DEP");
        courses.add("ABSD");

        txtName.clear();
        txtStudentId.clear();
        txtStudentName.clear();
        cmbCourse.getSelectionModel().clearSelection();
        cmbStudentID.getSelectionModel().clearSelection();
        lstCourses.getItems().clear();

        txtName.setDisable(true);

        cmbStudentID.getSelectionModel().selectedItemProperty().addListener(new ChangeListener<String>() {
            @Override
            public void changed(ObservableValue<? extends String> observable, String oldValue, String newValue) {
                String selectedStudentId = cmbStudentID.getSelectionModel().getSelectedItem();

                for (Student student : studentsDB) {
                    if (student.id.equals(selectedStudentId)){
                        txtName.setText(student.name);
                        break;
                    }
                }
            }
        });
    }

    public void btnNew_OnAction(ActionEvent actionEvent) {
        initialize();
    }

    public void btnRemove_OnAction(ActionEvent actionEvent) {
        ObservableList<String> courseItems = cmbCourse.getItems();
        ObservableList<String> items = lstCourses.getItems();

        String selectedItem = lstCourses.getSelectionModel().getSelectedItem();
        courseItems.add(selectedItem);
        items.remove(selectedItem);
    }

    public void btnClear_OnAction(ActionEvent actionEvent) {
        ObservableList<String> courseItems = cmbCourse.getItems();
        ObservableList<String> items = lstCourses.getItems();

        courseItems.addAll(items);
        items.clear();

    }

    public void btnSave_OnAction(ActionEvent actionEvent) {
        String id = txtStudentId.getText();
        String name = txtStudentName.getText();

        ObservableList<String> items = lstCourses.getItems();
        ArrayList<String> courses = new ArrayList<>(items);

        Student student = new Student(id, name, courses);
        studentsDB.add(student);

        ObservableList<String> studentIDList = cmbStudentID.getItems();
        studentIDList.add(student.id);
        initialize();
    }

    public void btnEdit_OnAction(ActionEvent actionEvent) {
        if (cmbStudentID.getSelectionModel().getSelectedIndex() == -1){
            return;
        }
        txtName.setDisable(false);
    }

    public void btnUpdate_OnAction(ActionEvent actionEvent) {
        String selectedStudentId = cmbStudentID.getSelectionModel().getSelectedItem();
        for (Student student : studentsDB) {
            if (student.id.equals(selectedStudentId)){
                student.name = txtName.getText();
                break;
            }
        }
    }

    public void btnRemoveStudent_OnAction(ActionEvent actionEvent) {
        String selectedStudentId = cmbStudentID.getSelectionModel().getSelectedItem();
        for (Student student : studentsDB) {
            if (student.id.equals(selectedStudentId)){
                studentsDB.remove(student);
                cmbStudentID.getItems().remove(selectedStudentId);
                initialize();
                break;
            }
        }
    }

    public void btnAdd_OnAction(ActionEvent actionEvent) {
        ObservableList<String> courseItems = cmbCourse.getItems();
        ObservableList<String> items = lstCourses.getItems();

        String selectedItem = cmbCourse.getSelectionModel().getSelectedItem();
        items.add(selectedItem);
        courseItems.remove(selectedItem);
    }
}
