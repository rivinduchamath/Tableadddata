import java.util.ArrayList;

public class Student {

    String id;
    String name;
    ArrayList<String> courses;

    public Student(String id, String name, ArrayList<String> courses) {
        this.id = id;
        this.name = name;
        this.courses = courses;
    }
}
